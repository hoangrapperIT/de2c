package com.example.admin.de2;

public class Model {
    public String MaSV;
    public String MaLop;
    public int dToan;
    public int dVan;

    public String getMaSV() {
        return MaSV;
    }

    public void setMaSV(String maSV) {
        MaSV = maSV;
    }

    public String getMaLop() {
        return MaLop;
    }

    public void setMaLop(String maLop) {
        MaLop = maLop;
    }

    public double getdToan() {
        return dToan;
    }

    public void setdToan(int dToan) {
        this.dToan = dToan;
    }

    public double getdVan() {
        return dVan;
    }

    public void setdVan(int dVan) {
        this.dVan = dVan;
    }
}